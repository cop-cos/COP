package cop;

import com.coscon.openapi.httpclient.*;

import java.io.IOException;

public class Demo {
    public static void main(String[] args) throws IOException {

        HttpClientCall httpClientCall = new HttpClientCall();

        // 自行填写
        // Input your hmac username and secret
        String hmacUsername = "";
        String hmacSecret = "";
        
        // 接口，自行填写
        // Input your api
        String url = "https://api-pp.lines.coscoshipping.com/service/synconhub/order/new";


        //参数，自行填写，json字符串
        // Input the api params, json
        String content = "";

        String method = "get";



        httpClientCall.callService(url, content, hmacUsername, hmacSecret, method);

    }

}


