/*
 * @(#)AbstractOpenAPI.java Created on 2018年12月24日
 *
 *================================================================
 *
 * (c) Copyright COSCON IT. 2017. All rights reserved.
 * 上海中远资讯科技股份有限公司版权所有版权所有.
 * www.cosconit.com
 */
package com.coscon.openapi.httpclient;

import com.coscon.openapi.pure.HmacPureExecutor;
import com.coscon.openapi.pure.OpenClientSecurityException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicLineFormatter;
import org.apache.http.protocol.HttpContext;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;


/**
 * Type comment.
 *
 * @author <a href="mailto:chenjp2@coscon.com">Chen Jipeng</a>
 */
public class AbstractOpenAPI {

    public static final String OPENAPI_URL_BASE_PROD = "https://api-pp.lines.coscoshipping.com/service";
    private HmacPureExecutor hmacPureExecutor = null;
    private String[] hostPatterns = {"api-pp.lines.coscoshipping.com", "api-internal.lines.coscoshipping.com", "api.lines.coscoshipping.com", "172.32.225.87",
            "172.22.224.165"};
    private List<CloseableHttpClient> clients = new Vector<CloseableHttpClient>();

    public String getOpenapiBaseUri() {
        return OPENAPI_URL_BASE_PROD;
    }

    /**
     * @return the hmacPureExecutor
     */
    public HmacPureExecutor getHmacPureExecutor() {
        return hmacPureExecutor;
    }

    public boolean match(HttpRequest request, String[] patterns) {
        if (patterns == null || patterns.length == 0) {
            return true;
        }
        Header[] hostHeaders = request.getHeaders(HttpHeaders.HOST);
        if (hostHeaders == null || hostHeaders.length == 0) {
            return false;
        }
        String target = hostHeaders[0].getValue();
        if (StringUtils.isBlank(target)) {
            return true;
        }
        if (target.contains(":")) {
            target = target.substring(0, target.indexOf(":"));
        }
        target = target.toUpperCase();
        for (String pattern : patterns) {
            if (StringUtils.isBlank(pattern)) {
                continue;
            }
            pattern = pattern.toUpperCase();
            if ("*".equals(pattern)) {
                return true;
            } else {
                if (pattern.endsWith("*")) {
                    if (target.startsWith(pattern.substring(0, pattern.length() - 1))) {
                        return true;
                    }
                } else if (pattern.startsWith("*")) {
                    if (target.endsWith(pattern.substring(1, pattern.length()))) {
                        return true;
                    }
                } else if (pattern.equals(target)) {
                    return true;
                }
            }
        }
        /**
         * None of patterns match.
         */
        return false;
    }



    /**
     * @return the client
     */
    public CloseableHttpClient createClient(final String username, final String secret) {

        HttpClientBuilder builder = HttpClientBuilder.create();
        builder.addInterceptorLast(new HttpRequestInterceptor() {
            public void process(HttpRequest request, HttpContext context) throws IOException {
                if (!match(request, hostPatterns)) {
                    return;
                }
                byte[] httpContent = new byte[0];
                if (request instanceof HttpEntityEnclosingRequest) {
                    HttpEntity entity = ((HttpEntityEnclosingRequest) request).getEntity();
                    if (entity != null) {
                        httpContent = IOUtils.toByteArray(entity.getContent());
                    }
                }
                try {

                    hmacPureExecutor = new HmacPureExecutor();
                    hmacPureExecutor.setApiKey(username);
                    hmacPureExecutor.setSecretKey(secret);

                    Map<String, String> headers = hmacPureExecutor.buildHmacHeaders(request.getRequestLine().toString(), httpContent);
                    if (headers != null) {
                        for (Entry<String, String> e : headers.entrySet()) {
                            request.addHeader(e.getKey(), e.getValue());
                        }
                    }

                    //request.addHeader("json_data",  "{\"SPT1\":\"\",\"SPT2\":\"\",\"SPT3\":\"\",\"messageCode\":\"200010\",\"messageTime\":\"2020-01-15T12:11:01\",\"platformSerno\":\"CARACZ2018022800000089566\",\"userID\":\"aczsap0101\",\"userToken\":\"eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1NzkwNjU2MDgsInVzZXJJZCI6ImFjenNhcDAxMDEifQ.3tvfX3W3oJIL8RuMJaCo65QD2QEhOabNF-z1F8Vye4k\"}");
                } catch (OpenClientSecurityException e) {
                    e.printStackTrace();
                }
            }
        });
        CloseableHttpClient client = builder.build();
        clients.add(client);
        return client;
    }


    public CloseableHttpClient createClientNTLMProxy(final String proxyUser, final String proxyPwd, final String domain,
                                                final String proxyHost, final int proxyPort, final String username, final String secret) {

        CredentialsProvider credsProvider = new BasicCredentialsProvider();

        NTCredentials creds = new NTCredentials(proxyUser, proxyPwd, "", domain);
        credsProvider.setCredentials(new AuthScope(proxyHost, proxyPort, null, "ntlm"), creds);
        CloseableHttpClient httpclient = HttpClients.custom()
                .setDefaultCredentialsProvider(credsProvider).addInterceptorLast(new HttpRequestInterceptor() {
                    public void process(HttpRequest request, HttpContext context) throws IOException {
                        if (!match(request, hostPatterns)) {
                            return;
                        }
                        byte[] httpContent = new byte[0];
                        if (request instanceof HttpEntityEnclosingRequest) {
                            HttpEntity entity = ((HttpEntityEnclosingRequest) request).getEntity();
                            if (entity != null) {
                                httpContent = IOUtils.toByteArray(entity.getContent());
                            }
                        }
                        try {

                            hmacPureExecutor = new HmacPureExecutor();
                            hmacPureExecutor.setApiKey(username);
                            hmacPureExecutor.setSecretKey(secret);

                            Map<String, String> headers = hmacPureExecutor.buildHmacHeaders(request.getRequestLine().toString(), httpContent);
                            if (headers != null) {
                                for (Entry<String, String> e : headers.entrySet()) {
                                    request.addHeader(e.getKey(), e.getValue());
                                }
                            }

                        } catch (OpenClientSecurityException e) {
                            e.printStackTrace();
                        }
                    }
                })
                .build();

        clients.add(httpclient);
        return httpclient;


    }

    public CloseableHttpClient createClientProxy(final String domain, final String username, final String secret) {

        CredentialsProvider credsProvider = new BasicCredentialsProvider();

//        NTCredentials creds = new NTCredentials(proxyUser, proxyPwd, "", domain);
//        credsProvider.setCredentials(new AuthScope(proxyHost, proxyPort, null, "ntlm"), creds);
//        CloseableHttpClient httpclient = HttpClients.custom()
//                .setDefaultCredentialsProvider(credsProvider).addInterceptorLast(new HttpRequestInterceptor() {
        CloseableHttpClient httpclient = HttpClients.custom().addInterceptorLast(new HttpRequestInterceptor() {
            public void process(HttpRequest request, HttpContext context) throws IOException {
                if (!match(request, hostPatterns)) {
                    return;
                }
                byte[] httpContent = new byte[0];
                if (request instanceof HttpEntityEnclosingRequest) {
                    HttpEntity entity = ((HttpEntityEnclosingRequest) request).getEntity();
                    if (entity != null) {
                        httpContent = IOUtils.toByteArray(entity.getContent());
                    }
                }
                try {

                    hmacPureExecutor = new HmacPureExecutor();
                    hmacPureExecutor.setApiKey(username);
                    hmacPureExecutor.setSecretKey(secret);

                    Map<String, String> headers = hmacPureExecutor.buildHmacHeaders(request.getRequestLine().toString(), httpContent);
                    if (headers != null) {
                        for (Entry<String, String> e : headers.entrySet()) {
                            request.addHeader(e.getKey(), e.getValue());
                        }
                    }

                } catch (OpenClientSecurityException e) {
                    e.printStackTrace();
                }
            }
        })
                .build();

        clients.add(httpclient);
        return httpclient;


    }




    public Map<String, String> getHmacHeaders(final String username, final String secret, String content, String method, String uri) throws IOException {

        byte[] httpContent = IOUtils.toByteArray(content);

        Map<String, String> headers = new HashMap<String, String>();

        try {

            hmacPureExecutor = new HmacPureExecutor();
            hmacPureExecutor.setApiKey(username);
            hmacPureExecutor.setSecretKey(secret);
            //httpclient默认配置为http/1.1，也可以手动调整配置，API Gateway都可以完成校验（protocol与实际相符即可）
            String requestLine = method.toUpperCase()+" "+uri+" HTTP/1.1";

            headers = hmacPureExecutor.buildHmacHeaders(requestLine, httpContent);

        } catch (OpenClientSecurityException e) {
            e.printStackTrace();
        }

        return headers;

    }


    private static final class HmacHttpSecurityRequestLine implements RequestLine {
        private RequestLine source = null;

        /**
         * Default constructor.
         *
         * @param source the original {@link RequestLine} instance.
         */
        public HmacHttpSecurityRequestLine(RequestLine source) {
            this.source = source;
        }

        @Override
        public String getMethod() {
            return source.getMethod();
        }

        @Override
        public ProtocolVersion getProtocolVersion() {
            return source.getProtocolVersion();
        }

        @Override
        public String getUri() {
            URI uri = URI.create(source.getUri());
            StringBuffer sb = new StringBuffer();
            if (uri.getPath() != null) {
                sb.append(uri.getRawPath());
            } else {
                sb.append("/");
            }
            if (uri.getQuery() != null) {
                sb.append('?');
                sb.append(uri.getRawQuery());
            }
            return sb.toString();
        }

        @Override
        public String toString() {
            return BasicLineFormatter.INSTANCE.formatRequestLine(null, this).toString();
        }
    }



}
