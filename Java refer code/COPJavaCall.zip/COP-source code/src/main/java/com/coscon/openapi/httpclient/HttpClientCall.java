/*
 * @(#)HttpClientCall.java Created on 2018?12?24?
 *
 *================================================================
 *
 * (c) Copyright COSCON IT. 2017. All rights reserved.
 * ??????????????????????.
 * www.cosconit.com
 */
package com.coscon.openapi.httpclient;


import com.alibaba.fastjson.JSON;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;

//import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Type comment.
 *
 * @author <a href="mailto:chenjp2@coscon.com">Chen Jipeng</a>
 *
 */

public class HttpClientCall extends AbstractOpenAPI {

    Charset utf8Charset = Charset.forName("utf-8");
    Charset iso88591Charset = Charset.forName("iso-8859-1");

    public String callProxyService(String proxyHost, int proxyPort, String proxyUsr, String proxyPwd, String domain,
                                 String targetHost, String uri, String method, String content,
                                 String username, String secret) throws IOException {

        org.apache.http.client.HttpClient client = createClientNTLMProxy(proxyUsr, proxyPwd, domain, proxyHost, proxyPort, username, secret);

        HttpHost target = new HttpHost(targetHost, 443, "https");

        HttpContext localContext = new BasicHttpContext();

        String resultText = "";

        if (method.equalsIgnoreCase("post")){
            HttpPost httpPost = new HttpPost(uri);

            Map<String, String> map = getHmacHeaders(username, secret, content, method, uri);
            for (Map.Entry<String, String> e : map.entrySet()) {
                httpPost.addHeader(e.getKey(), e.getValue());
            }
            //httpPost.setProtocolVersion(HttpVersion.HTTP_1_0);
//            StringEntity entity = new StringEntity(content, UTF_8);
            StringEntity entity = new StringEntity(content, "utf-8");
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            httpPost.setEntity(entity);
            HttpResponse response = client.execute(target, httpPost, localContext);
//            System.out.println("response: " + response);
            String responseText = EntityUtils.toString(response.getEntity());

            resultText = StringUtils.toEncodedString(responseText.getBytes(iso88591Charset), utf8Charset);

//            System.out.println(resultText);


        }else if (method.equalsIgnoreCase("get")){

            HttpGet httpGet = new HttpGet(uri);
            //httpGet.setProtocolVersion(HttpVersion.HTTP_1_0);
            Map<String, String> map = getHmacHeaders(username, secret, content, method, uri);
            for (Map.Entry<String, String> e : map.entrySet()) {
                httpGet.addHeader(e.getKey(), e.getValue());
            }

            HttpResponse response = client.execute(target, httpGet, localContext);
            String responseText = EntityUtils.toString(response.getEntity());

            resultText = StringUtils.toEncodedString(responseText.getBytes(iso88591Charset), utf8Charset);

//            System.out.println(resultText);


        }else {
            System.out.println("Error: Please input get/post as method.");
        }

        try {
            ((CloseableHttpClient) client).close();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return resultText;

    }



    public String callService(String uri, String content, String username, String secret, String method) throws IOException {

        org.apache.http.client.HttpClient client = createClient(username, secret);

        String responseText = "";

        String resultText = "";

        if (method.equalsIgnoreCase("post")){

            HttpPost httpPost = new HttpPost(uri);

//            StringEntity entity = new StringEntity(content, UTF_8);
            StringEntity entity = new StringEntity(content, "utf-8");
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
//            entity.setContentType("application/json;charset=UTF-8");
            httpPost.setEntity(entity);

            HttpResponse response = client.execute(httpPost);
            responseText = EntityUtils.toString(response.getEntity());

            resultText = StringUtils.toEncodedString(responseText.getBytes(iso88591Charset), utf8Charset);

//            System.out.println(resultText);


        }else if (method.equalsIgnoreCase("get")){

            HttpGet httpGet = new HttpGet(uri);
            HttpResponse response = client.execute(httpGet);
            responseText = EntityUtils.toString(response.getEntity());
            System.out.println(resultText);


        }

        try {
            ((CloseableHttpClient) client).close();
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println(responseText);

        return responseText;

    }

    public static void main(String[] args) throws IOException {

        HttpClientCall httpClientCall = new HttpClientCall();

        // 自行填写
        // Input your hamc username and secret
        String hmacUsername = "";
        String hmacSecret = "";


        // 接口，自行填写
        // Input your api
        String url = "";


        //参数，自行填写，json字符串
        //Input api content,json
        String content = "";


        String method = "post";



        httpClientCall.callService(url, content, hmacUsername, hmacSecret, method);

    }
}
