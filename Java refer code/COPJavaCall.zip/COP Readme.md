### COP代码说明

此COP代码为java版本，有两种调用方法：jar包调用与源码调用。

#### jar包调用
在项目中导入jar包
在java文件DemoEportal.java中有一个main方法，填写给定的hmacUsername与hmacSecret, url为调用接口，content为接口参数，method指定get或post，运行即可

#### 源码调用
导入java项目，在HTTPClientCall.java中有一个main方法，参数与之前描述相同，运行即可。


### Description of COP code

The COP code is Java version, you can call the api via jar or source code.

#### Call api via jar
Import jar into your project
A main method can be found in "Demo.java".
Input your hamc username, secret, the api url and the content.
Method is "get" or "post"
Run

#### Call api via source code
Import the java project
A main method can be found in "HTTPClientCall.java"
Input your hamc username, secret, the api url and the content.
Method is "get" or "post"
Run